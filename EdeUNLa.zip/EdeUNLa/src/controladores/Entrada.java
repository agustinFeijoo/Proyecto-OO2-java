package controladores;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/Entradas")
public class Entrada extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		
		int tipoDePeticion=Integer.parseInt(req.getParameter("seleccion"));//1 ABM 2 Reporte
		int numPeticion=Integer.parseInt(req.getParameter("opt"));
		if(tipoDePeticion==1) {
			switch(numPeticion) {
			case 1://ABM de clientes
				 resp.sendRedirect(req.getContextPath() + "/ClientesABM.jsp");
				/*RequestDispatcher dispatcher = getServletContext()
			      .getRequestDispatcher("/forwarded");
			    dispatcher.forward(req, resp);
				*/
				//resp.getWriter().append("Served at: ").append(req.getContextPath());
			break;
				
			}
		}else {
			switch(numPeticion) {
				case 1:
					
			}
		}
		
	}

	public void init(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
		}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	


}
