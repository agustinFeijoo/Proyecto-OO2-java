package controladores;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ClienteDao;
import datos.Cliente;
import datos.DatosPersonales;
import negocio.ClienteABM;
import negocio.DatosPersonalesABM;




/**
 * Servlet implementation class MostrarClientes
 */
@WebServlet("/MostrarClientes")
public class MostrarClientes extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//private ModeloProducto modeloProducto;
	//@Resource(name="jdbc/nombrePoolConnection")
	//private DataSource miPool;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MostrarClientes() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
    
	public void procesarPeticion(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
		super.init();
		/*
		response.setContentType("text/html;chatset=UTF-8");
		try {
			ClienteABM clienteABM=new ClienteABM();
			Cliente cliente=clienteABM.traerCliente(1);
			response.setStatus(200);
			PrintWriter salida=response.getWriter()	;
			salida.print("");
			salida.println("<!DOCTYPE 4.01 Transitional//EN\">");
			salida.println("<HTML>");
			salida.println("<HEAD>");
			salida.println("<TITLE>Mostrar Clientes</TITLE>");
			salida.println("</HEAD>");
			salida.println("<BODY>");
			salida.println("DNI:"+cliente.getDatosPersonales().getDni());
			salida.println("/BODY");
			salida.println("</HTML>");
		//System.out.println(cliente.getDatosPersonales().getDni());
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		*/
	}

	public void init(HttpServletRequest request,HttpServletResponse response) throws ServletException{
		super.init();
		}
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ClienteABM clienteABM=new ClienteABM();
		DatosPersonalesABM datosPersonalesABM=new DatosPersonalesABM();
		Cliente c;
		DatosPersonales dp;
		ClienteDao clienteDao=ClienteDao.getInstanciaClienteDao();
		// TODO Auto-generated method stub
		int idCliente;
		if(request.getParameter("borrar")!=null){
		idCliente=Integer.parseInt(request.getParameter("idCliente"));
		clienteABM.eliminar(idCliente);
		datosPersonalesABM.eliminar(idCliente);
		}
		if(request.getParameter("guardar")!=null) {
			long dni=Long.parseLong(request.getParameter("dni"));
			String apellido=request.getParameter("apellido");
			String nombre=request.getParameter("nombre");
			String telefono=request.getParameter("telefono");
			//dp=new DatosPersonales(dni,apellido,nombre,null,null,telefono);
			idCliente=Integer.parseInt(request.getParameter("idCliente"));//es 0 en caso de que venga de agregar
			
			//c=new Cliente(dp);
			try {
				if(request.getParameter("vieneDeModificacion").equals("1")) {
					dp=clienteDao.traerCliente(idCliente).getDatosPersonales();
					dp.setApellido(apellido);
					dp.setNombre(nombre);
					dp.setDni(dni);
					dp.setTelefono(telefono);
					
					datosPersonalesABM.modificar(dp);
				}else
				clienteABM.agregar(dni,apellido,nombre,null,null,telefono);
				
			}catch(Exception e) {
				e.printStackTrace();
			}
			
		}
		//response.getWriter().append("Served at: "+request.getParameter("borrar")).append(request.getContextPath());
		
		if(request.getParameter("mostrar").equals("1")) {
			clienteABM.mostrarFilas(response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		procesarPeticion(request,response);
	}

}
