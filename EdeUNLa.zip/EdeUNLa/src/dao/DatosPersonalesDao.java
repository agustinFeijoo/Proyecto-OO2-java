package dao;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import datos.DatosPersonales;
public class DatosPersonalesDao {

	private static DatosPersonalesDao instanciaDatosPersonalesDao;

	private static Session session;
	private Transaction tx;
	
	protected DatosPersonalesDao() {
		
	}
	
	public static DatosPersonalesDao getInstanciaDatosPersonalesDao() {
		if(instanciaDatosPersonalesDao==null)
			instanciaDatosPersonalesDao= new DatosPersonalesDao();
		return instanciaDatosPersonalesDao;
	}
	

	private void iniciaOperacion() throws HibernateException {
		session = HibernateUtil.getSessionFactory().openSession();
		tx = session.beginTransaction();
	}

	private void manejaExcepcion(HibernateException he) throws HibernateException {
		tx.rollback();
		throw new HibernateException("ERROR en la capa de acceso a datos", he);
	}

	public int agregar(DatosPersonales objeto) {
		int id = 0;
		try {
			iniciaOperacion();
			id = Integer.parseInt(session.save(objeto).toString());
			tx.commit();
		} catch (HibernateException he) {
			manejaExcepcion(he);
			throw he;
		} finally {
			session.close();
		}
		return id;
	}

	public void actualizar(DatosPersonales objeto) throws HibernateException {
		try {
			iniciaOperacion();
			session.update(objeto);
			
			tx.commit();
		} catch (HibernateException he) {
			manejaExcepcion(he);
			throw he;
		} finally {
			session.close();
		}
	}

	public void eliminar(DatosPersonales objeto) throws HibernateException {
		try {
			iniciaOperacion();
			session.delete(objeto);
			tx.commit();
		} catch (HibernateException he) {
			manejaExcepcion(he);
			throw he;
		} finally {
			session.close();
		}
	}

	public DatosPersonales traer(int idDatosPersonales) throws HibernateException {
		DatosPersonales objeto = null;
		try {
			iniciaOperacion();
			objeto = (DatosPersonales) session.get(DatosPersonales.class, idDatosPersonales);
		} finally {

			session.close();
		}
		return objeto;
	}

	public DatosPersonales traer(long dni) throws HibernateException {
		DatosPersonales objeto = null;
		try {
			iniciaOperacion();
			objeto = (DatosPersonales) session.createQuery("from DatosPersonales d where d.dni=" + dni).uniqueResult();
		} finally {
			session.close();
		}
		return objeto;
	}


}
