package dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import datos.LecturaAD;

public class LecturaAltaDao {
	private static Session session;
	private Transaction tx;
	private static LecturaAltaDao instancia = null;

	protected LecturaAltaDao() {
	}

	public static LecturaAltaDao getInstance() {
		if (instancia == null)
			instancia = new LecturaAltaDao();
		return instancia;
	}

	protected void iniciaOperacion() throws HibernateException {
		session = HibernateUtil.getSessionFactory().openSession();
		tx = session.beginTransaction();
	}

	protected void manejaExcepcion(HibernateException he) throws HibernateException {
		tx.rollback();
		throw new HibernateException("ERROR en la capa de acceso a datos", he);
	}

	public LecturaAD traer(int idLectura) {
		LecturaAD objeto = null;
		try {
			iniciaOperacion();
			objeto = (LecturaAD) session.createQuery("from LecturaAD l where l.idLectura =" + idLectura).uniqueResult();
		} finally {
			session.close();
		}
		return objeto;
	}

	
	
	public int agregar(LecturaAD objeto) {
		int id = 0;
		try {
			iniciaOperacion();
			id = Integer.parseInt(session.save(objeto).toString());
			tx.commit();
		} catch (HibernateException he) {
			manejaExcepcion(he);
			throw he;
		} finally {
			session.close();
		}
		return id;
	}

	public void actualizar(LecturaAD objeto) throws HibernateException {
		try {
			iniciaOperacion();
			session.update(objeto);
			tx.commit();
		} catch (HibernateException he) {
			manejaExcepcion(he);
			throw he;
		} finally {
			session.close();
		}
	}

	public void eliminar(LecturaAD objeto) throws HibernateException {
		try {
			iniciaOperacion();
			session.delete(objeto);
			tx.commit();
		} catch (HibernateException he) {
			manejaExcepcion(he);
			throw he;
		} finally {
			session.close();
		}
	}
}
