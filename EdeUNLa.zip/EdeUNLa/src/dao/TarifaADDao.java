package dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import datos.TarifaAD;

public class TarifaADDao {
	private static Session session;
	private Transaction tx;
	private static TarifaADDao instancia = null;
	
	protected TarifaADDao() {
	}

	public static TarifaADDao getInstance() {
		if (instancia == null)
			instancia = new TarifaADDao();
		return instancia;
	}

	protected void iniciaOperacion() throws HibernateException {
		session = HibernateUtil.getSessionFactory().openSession();
		tx = session.beginTransaction();
	}

	protected void manejaExcepcion(HibernateException he) throws HibernateException {
		tx.rollback();
		throw new HibernateException("ERROR en la capa de acceso a datos", he);
	}

	public TarifaAD traer(int idTarifaAD) {
		TarifaAD objeto = null;
		try {
			iniciaOperacion();
			objeto = (TarifaAD) session.get(TarifaAD.class, idTarifaAD);
		} finally {
			session.close();
		}
		return objeto;
	}
}
