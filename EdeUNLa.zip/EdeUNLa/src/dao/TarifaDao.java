package dao;

import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import datos.Inspector;
import datos.Tarifa;

public class TarifaDao {

	private static Session session;
	private Transaction tx;
	private static TarifaDao instancia = null;

	protected TarifaDao() {
	}

	public static TarifaDao getInstance() {
		if (instancia == null)
			instancia = new TarifaDao();
		return instancia;
	}

	protected void iniciaOperacion() throws HibernateException {
		session = HibernateUtil.getSessionFactory().openSession();
		tx = session.beginTransaction();
	}

	protected void manejaExcepcion(HibernateException he) throws HibernateException {
		tx.rollback();
		throw new HibernateException("ERROR en la capa de acceso a datos", he);
	}

	public Tarifa traer(int idTarifa) {
		Tarifa objeto = null;
		try {
			iniciaOperacion();
			objeto = (Tarifa) session.createQuery("from Tarifa l where l.idTarifa =" + idTarifa).uniqueResult();
		} finally {
			session.close();
		}
		return objeto;
	}

	
	public Tarifa traer(String categoria) {
		Tarifa objeto = null;
		try {
			iniciaOperacion();
			objeto = (Tarifa) session.createQuery("from Tarifa l where l.categoria ='" + categoria+"'").uniqueResult();
		} finally {
			session.close();
		}
		return objeto;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<Tarifa> traer() throws HibernateException {
		List<Tarifa> lista = null;
		try {
			iniciaOperacion();
			lista = session.createQuery("from Tarifa").list();
		} finally {
			session.close();
		}
		return lista;
	}
	
//	public int agregar(Tarifa objeto) {
//		int id = 0;
//		try {
//			iniciaOperacion();
//			id = Integer.parseInt(session.save(objeto).toString());
//			tx.commit();
//		} catch (HibernateException he) {
//			manejaExcepcion(he);
//			throw he;
//		} finally {
//			session.close();
//		}
//		return id;
//	}
//
//	public void actualizar(Tarifa objeto) throws HibernateException {
//		try {
//			iniciaOperacion();
//			session.update(objeto);
//			tx.commit();
//		} catch (HibernateException he) {
//			manejaExcepcion(he);
//			throw he;
//		} finally {
//			session.close();
//		}
//	}
//
//	public void eliminar(Tarifa objeto) throws HibernateException {
//		try {
//			iniciaOperacion();
//			session.delete(objeto);
//			tx.commit();
//		} catch (HibernateException he) {
//			manejaExcepcion(he);
//			throw he;
//		} finally {
//			session.close();
//		}
//	}
	
}
