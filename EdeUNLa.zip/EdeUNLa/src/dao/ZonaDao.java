package dao;

import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import datos.Inspector;
import datos.Zona;

public class ZonaDao {

	private static Session session;
	private Transaction tx;
	private static ZonaDao instancia = null; // Patron Singleton

	protected ZonaDao() {
	}

	public static ZonaDao getInstance() {
		if (instancia == null)
			instancia = new ZonaDao();
		return instancia;
	}

	protected void iniciaOperacion() throws HibernateException {
		session = HibernateUtil.getSessionFactory().openSession();
		tx = session.beginTransaction();
	}

	protected void manejaExcepcion(HibernateException he) throws HibernateException {
		tx.rollback();
		throw new HibernateException("ERROR en la capa de acceso a datos", he);
	}

	public Zona traer(int idZona) {
		Zona objeto = null;
		try {
			iniciaOperacion();
			objeto = (Zona) session.createQuery("from Zona l where l.idZona =" + idZona).uniqueResult();
		} finally {
			session.close();
		}
		return objeto;
	}
	
	public Zona traer(String descripcion) {
		Zona objeto = null;
		try {
			iniciaOperacion();
			objeto = (Zona) session.createQuery("from Zona l where l.descripcion ='" + descripcion+"'").uniqueResult();
		} finally {
			session.close();
		}
		return objeto;
	}

	@SuppressWarnings("unchecked")
	public List<Zona> traer() throws HibernateException {
		List<Zona> lista = null;
		try {
			iniciaOperacion();
			lista = session.createQuery("from Zona").list();
		} finally {
			session.close();
		}
		return lista;
	}
	
	public int agregar(Zona objeto) {
		int id = 0;
		try {
			iniciaOperacion();
			id = Integer.parseInt(session.save(objeto).toString());
			tx.commit();
		} catch (HibernateException he) {
			manejaExcepcion(he);
			throw he;
		} finally {
			session.close();
		}
		return id;
	}

	public void actualizar(Zona objeto) throws HibernateException {
		try {
			iniciaOperacion();
			session.update(objeto);
			tx.commit();
		} catch (HibernateException he) {
			manejaExcepcion(he);
			throw he;
		} finally {
			session.close();
		}
	}

	public void eliminar(Zona objeto) throws HibernateException {
		try {
			iniciaOperacion();
			session.delete(objeto);
			tx.commit();
		} catch (HibernateException he) {
			manejaExcepcion(he);
			throw he;
		} finally {
			session.close();
		}
	}
	
}
