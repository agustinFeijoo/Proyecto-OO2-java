package datos;
import java.util.Set;
public class Cliente {
	private int idCliente;
	private DatosPersonales datosPersonales;
	private Set<Factura> facturas;
	
	
	public Cliente() {}
	
	public Cliente(DatosPersonales datosPersonales) {
		this.datosPersonales=datosPersonales;
	}
	
	
	// el cliente puede tener varios medidores, va en Medidor el cliente
//	public Medidor getMedidor() {
//		return medidor;
//	}
//	public void setMedidor(Medidor medidor) {
//		this.medidor = medidor;
//	}
	public Set<Factura> getFacturas() {
		return facturas;
	}
	public void setFacturas(Set<Factura> facturas) {
		this.facturas = facturas;
	}
	public int getIdCliente() {
		return idCliente;
	}
	protected void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}
	public DatosPersonales getDatosPersonales() {
		return datosPersonales;
	}
	public void setDatosPersonales(DatosPersonales datosPersonales) {
		this.datosPersonales = datosPersonales;
	}
	
	
	@Override
	public String toString() {
		return "Cliente [idCliente=" + idCliente + ", datosPersonales=" + datosPersonales + "]";
	}
	
	
	
	
}
