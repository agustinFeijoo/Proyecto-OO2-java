package datos;


public class DatosPersonales {
	private int idDatosPersonales;
	private long dni;
	private String apellido;
	private String nombre;
	private String mail;
	private String direccion;
	private String telefono;

	public DatosPersonales() {}

	public DatosPersonales(long dni, String apellido, String nombre, String mail, String direccion, String telefono) {
		
		this.dni = dni;
		this.apellido = apellido;
		this.nombre = nombre;
		this.mail = mail;
		this.direccion = direccion;
		this.telefono = telefono;

	}


	public int getIdDatosPersonales() {
		return idDatosPersonales;
	}

	protected void setIdDatosPersonales(int idDatos) {
		this.idDatosPersonales = idDatos;
	}

	public long getDni() {
		return dni;
	}

	public void setDni(long dni) {
		this.dni = dni;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	@Override
	public String toString() {
		return "DatosPersonales [idDatos=" + idDatosPersonales + ", dni=" + dni + ", apellido=" + apellido + ", nombre=" + nombre
				+ ", mail=" + mail + ", direccion=" + direccion + ", telefono=" + telefono + "]";
	}

	
	
	
	
}
