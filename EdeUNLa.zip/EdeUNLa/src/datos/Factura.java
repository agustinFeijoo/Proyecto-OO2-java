package datos;

import java.time.LocalDate;

public class Factura {
	private int idFactura;
	private int nroSerieMedidor;
	private String observaciones;
	private boolean anulada;
	private LocalDate fecha;
	private Cliente cliente;

	
	public Factura(int idFactura, int nroSerieMedidor, String observaciones,
			boolean anulada, LocalDate fecha,Cliente cliente ) {
		super();
		this.idFactura = idFactura;
		this.nroSerieMedidor = nroSerieMedidor;
		this.observaciones = observaciones;
		this.anulada = anulada;
		this.fecha = fecha;
		this.cliente=cliente;
	}
	


	public Cliente getCliente() {
		return cliente;
	}



	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}



	public String getObservaciones() {
		return observaciones;
	}



	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}



	public boolean isAnulada() {
		return anulada;
	}



	public void setAnulada(boolean anulada) {
		this.anulada = anulada;
	}



	public int getNroSerieMedidor() {
		return nroSerieMedidor;
	}


	public void setNroSerieMedidor(int nroSerieMedidor) {
		this.nroSerieMedidor = nroSerieMedidor;
	}


	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public int getIdFactura() {
		return idFactura;
	}
	public void setIdFactura(int idFactura) {
		this.idFactura = idFactura;
	}
	
}
