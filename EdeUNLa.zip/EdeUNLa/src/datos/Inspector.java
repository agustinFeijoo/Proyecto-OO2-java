package datos;


import java.util.Set;

public class Inspector {
	private int idInspector;
	private DatosPersonales datosPersonales;
	private Set<Zona> lstZonas;
	
	public Inspector() {}

	public Inspector(DatosPersonales datosPersonales) {
		super();
		this.datosPersonales = datosPersonales;
	}

	public int getIdInspector() {
		return idInspector;
	}

	protected void setIdInspector(int idInspector) {
		this.idInspector = idInspector;
	}

	public DatosPersonales getDatosPersonales() {
		return datosPersonales;
	}

	public void setDatosPersonales(DatosPersonales datosPersonales) {
		this.datosPersonales = datosPersonales;
	}


	public Set<Zona> getLstZonas() {
		return lstZonas;
	}

	public void setLstZonas(Set<Zona> lstZonas) {
		this.lstZonas = lstZonas;
	}

	@Override
	public String toString() {
		return "Inspector [idInspector=" + idInspector + ", datosPersonales=" + datosPersonales + "]";
	}
	
	
	
}
