package datos;

import java.time.LocalDate;

public abstract class Lectura {
	protected int idLectura;
	protected Inspector inspector;
	protected Medidor medidor;
	protected LocalDate fecha;
	
	public Lectura() {}

	public Lectura(Inspector inspector, Medidor medidor, LocalDate fecha) {
		this.inspector = inspector;
		this.medidor = medidor;
		this.fecha = fecha;
	}

	public int getIdLectura() {
		return idLectura;
	}

	protected void setIdLectura(int idLectura) {
		this.idLectura = idLectura;
	}

	public Inspector getInspector() {
		return inspector;
	}

	public void setInspector(Inspector inspector) {
		this.inspector = inspector;
	}

	public Medidor getMedidor() {
		return medidor;
	}

	public void setMedidor(Medidor medidor) {
		this.medidor = medidor;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	@Override
	public String toString() {
		return "Lectura [idLectura=" + idLectura + ", inspector=" + inspector + ", medidor=" + medidor + ", fecha="
				+ fecha + "]";
	}

	
	
}
