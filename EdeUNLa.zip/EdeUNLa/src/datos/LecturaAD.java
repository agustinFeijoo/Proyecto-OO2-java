package datos;

import java.time.LocalDate;

public class LecturaAD extends Lectura{
	private int idLecturaAD;
	private float consumoPico;
	private float consumoResto;
	private float consumoValle;
	
	public LecturaAD() {}
	
	public LecturaAD(Inspector inspector, Medidor medidor, LocalDate fecha,float consumoPico,float consumoValle, float consumoResto) {
		super(inspector,medidor,fecha);
		this.consumoPico=consumoPico;
		this.consumoResto=consumoResto;
		this.consumoValle=consumoValle;
	}
	public int getIdLecturaAD() {
		return idLecturaAD;
	}
	protected void setIdLecturaAD(int idLecturaAD) {
		this.idLecturaAD = idLecturaAD;
	}
	public float getConsumoPico() {
		return consumoPico;
	}
	public void setConsumoPico(float consumoPico) {
		this.consumoPico = consumoPico;
	}
	public float getConsumoResto() {
		return consumoResto;
	}
	public void setConsumoResto(float consumoResto) {
		this.consumoResto = consumoResto;
	}
	public float getConsumoValle() {
		return consumoValle;
	}
	public void setConsumoValle(float consumoValle) {
		this.consumoValle = consumoValle;
	}
	@Override
	public String toString() {
		return "LecturaAD [idLecturaAD=" + idLecturaAD + 
				", fecha="	+fecha+ ", consumoPico=" + consumoPico + ", consumoResto="
				+ consumoResto + ", consumoValle=" + consumoValle + "]";
	}
	
	
	
	
	
}
