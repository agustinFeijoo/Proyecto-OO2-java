package datos;

import java.time.LocalDate;

public class LecturaBD extends Lectura {
	private int idLecturaBd;
	private float consumo;

	public LecturaBD() {
	}

	public LecturaBD(Inspector inspector, Medidor medidor, LocalDate fecha, float consumo) {
		super(inspector, medidor, fecha);
		this.consumo = consumo;
	}

	public int getIdLecturaBd() {
		return idLecturaBd;
	}

	protected void setIdLecturaBd(int idLecturaBd) {
		this.idLecturaBd = idLecturaBd;
	}

	public float getConsumo() {
		return consumo;
	}

	public void setConsumo(float consumo) {
		this.consumo = consumo;
	}

	@Override
	public String toString() {
		return "LecturaBD [idLecturaBd=" + idLecturaBd
				+ ", fecha=" + fecha + ", consumo=" + consumo + "]";
	}

}
