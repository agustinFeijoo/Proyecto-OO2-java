package datos;

public class Medidor {
	private int idMedidor;
	private long nroSerie;
	private Cliente cliente;
	private String descripcion;
	private Zona zona;
	private String tipoDemanda;
	private Tarifa tarifa;

	
	public Medidor() {}
	
	public Medidor(long nroSerie, Cliente cliente, String descripcion, Zona zona, String tipoDemanda, Tarifa tarifa) {
		this.nroSerie = nroSerie;
		this.cliente = cliente;
		this.descripcion = descripcion;
		this.zona = zona;
		this.tipoDemanda = tipoDemanda;
		this.tarifa = tarifa;
	}

	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public int getIdMedidor() {
		return idMedidor;
	}

	protected void setIdMedidor(int idMedidor) {
		this.idMedidor = idMedidor;
	}

	public long getNroSerie() {
		return nroSerie;
	}

	public void setNroSerie(long nroSerie) {
		this.nroSerie = nroSerie;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public String getdescripcion() {
		return descripcion;
	}

	public void setdescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Zona getZona() {
		return zona;
	}

	public void setZona(Zona zona) {
		this.zona = zona;
	}

	public String getTipoDemanda() {
		return tipoDemanda;
	}

	public void setTipoDemanda(String tipoDemanda) {
		this.tipoDemanda = tipoDemanda;
	}

	public Tarifa getTarifa() {
		return tarifa;
	}

	public void setTarifa(Tarifa tarifa) {
		this.tarifa = tarifa;
	}

//	@Override
//	public String toString() {
//		return "Medidor [idMedidor=" + idMedidor + ", nroSerie=" + nroSerie + ", cliente=" + cliente + ", descripcion="
//				+ descripcion + ", zona=" + zona + ", tipoDemanda=" + tipoDemanda + ", tarifa=" + tarifa + "]";
//		//ver cliente,zona y tarifa
//	}
	
	@Override
	public String toString() {
		return "Medidor [idMedidor=" + idMedidor + ", nroSerie=" + nroSerie + ", cliente=" + cliente.getDatosPersonales().getDni() + ", descripcion="
				+ descripcion + ", zona=" + zona.getDescripcion() + ", tipoDemanda=" + tipoDemanda + ", tarifa=" + tarifa.getCategoria() + "]";
		//ver cliente,zona y tarifa
	}
	
	
	
	
}
