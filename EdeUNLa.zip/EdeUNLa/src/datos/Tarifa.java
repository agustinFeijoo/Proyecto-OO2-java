package datos;

public abstract class Tarifa {
	protected int idTarifa;
	protected String categoria;
	protected float cargoFijo;
	public Tarifa() {}
	
	public Tarifa( String categoria, float cargoFijo) {
		this.categoria=categoria;
		this.cargoFijo=cargoFijo;
	}

	public int getIdTarifa() {
		return idTarifa;
	}
	protected void setIdTarifa(int idTarifa) {
		this.idTarifa = idTarifa;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public float getCargoFijo() {
		return cargoFijo;
	}
	public void setCargoFijo(float cargoFijo) {
		this.cargoFijo = cargoFijo;
	}
	@Override
	public String toString() {
		return "Tarifa [idTarifa=" + idTarifa + ", categoria=" + categoria + ", cargoFijo=" + cargoFijo + "]";
	}
	
	
}
