package datos;

public class TarifaAD extends Tarifa {
	private int idTarifaAD;
	private float cargoVarPico;
	private float cargoVarResto;
	private float cargoVarValle;
	
	public TarifaAD() {}

	public TarifaAD(String categoria, float cargoFijo, float cargoVarPico,
			float cargoVarResto, float cargoVarValle) {
		super( categoria, cargoFijo);
		this.cargoVarPico = cargoVarPico;
		this.cargoVarResto = cargoVarResto;
		this.cargoVarValle = cargoVarValle;
	}

	public int getIdTarifaAD() {
		return idTarifaAD;
	}

	protected void setIdTarifaAD(int idTarifaAD) {
		this.idTarifaAD = idTarifaAD;
	}

	public float getCargoVarPico() {
		return cargoVarPico;
	}

	public void setCargoVarPico(float cargoVarPico) {
		this.cargoVarPico = cargoVarPico;
	}

	public float getCargoVarResto() {
		return cargoVarResto;
	}

	public void setCargoVarResto(float cargoVarResto) {
		this.cargoVarResto = cargoVarResto;
	}

	public float getCargoVarValle() {
		return cargoVarValle;
	}

	public void setCargoVarValle(float cargoVarValle) {
		this.cargoVarValle = cargoVarValle;
	}

	@Override
	public String toString() {
		return "TarifaAD [idTarifaAD=" + idTarifaAD + ", categoria=" + categoria + ", cargoFijo="
				+ cargoFijo + ", cargoVarPico=" + cargoVarPico + ", cargoVarResto="
				+ cargoVarResto + ", cargoVarValle=" + cargoVarValle + "]";
	}
	
	
	
}
