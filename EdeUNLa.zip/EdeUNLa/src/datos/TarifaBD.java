package datos;

public class TarifaBD extends Tarifa {
	private int idTarifaBD;
	private int kwMin;
	private int kwMax;
	private float cargoVariable;
	
	public TarifaBD() {}

	public TarifaBD(int kwMin, int kwMax, float cargoVariable) {
		this.kwMin = kwMin;
		this.kwMax = kwMax;
		this.cargoVariable = cargoVariable;
	}

	public float getCargoVariable() {
		return cargoVariable;
	}

	public void setCargoVariable(float cargoVariable) {
		this.cargoVariable = cargoVariable;
	}

	public int getIdTarifaBD() {
		return idTarifaBD;
	}

	protected void setIdTarifaBD(int idTarifaBD) {
		this.idTarifaBD = idTarifaBD;
	}

	public int getKwMin() {
		return kwMin;
	}

	public void setKwMin(int kwMin) {
		this.kwMin = kwMin;
	}

	public int getKwMax() {
		return kwMax;
	}

	public void setKwMax(int kwMax) {
		this.kwMax = kwMax;
	}

	@Override
	public String toString() {
		return "TarifaBD [idTarifaBD=" + idTarifaBD + ", categoria=" + categoria + ", cargoFijo="
				+ cargoFijo + ", kwMin=" + kwMin + ", kwMax=" + kwMax + "]";
	}
	
	
	
	
	
}
