package datos;


import java.util.Set;

public class Zona {
	private int idZona;
	private Set<Inspector> lstInspector;
	private String descripcion;
	
	public Zona() {}

	public Zona(String descripcion) {
		this.descripcion = descripcion;
	}
	public Zona(String descripcion,Set<Inspector> lstInspector) {
		this.descripcion = descripcion;
		this.lstInspector=lstInspector;
	}
	
	
	public Set<Inspector> getLstInspector() {
		return lstInspector;
	}

	public void setLstInspector(Set<Inspector> lstInspector) {
		this.lstInspector = lstInspector;
	}

	public int getIdZona() {
		return idZona;
	}

	protected void setIdZona(int idZona) {
		this.idZona = idZona;
	}


	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Override
	public String toString() {
		return "Zona [idZona=" + idZona + ", lstInspector=" + lstInspector + ", descripcion=" + descripcion + "]";
	}
	
	
	
	
}
