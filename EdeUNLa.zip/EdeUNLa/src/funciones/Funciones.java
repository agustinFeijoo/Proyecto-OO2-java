package funciones;
import java.time.LocalDate;
import java.time.LocalTime;
public class Funciones {
	
	public static String traerFecha(LocalDate f) {
		//retorna "dd de mes de aaaa"
		return(f.getDayOfMonth()+" de "+f.getMonth()+" de "+f.getYear());
	}
	
	public static String traerFechaCorta(LocalDate f) {
		//retorna dd/mm/aaaa
		return (f.getDayOfMonth()+"/"+f.getMonthValue()+"/"+f.getYear());
	}
	
	public static String traerHora(LocalTime h) {
		return h.getHour()+":"+h.getMinute()+":"+h.getSecond();
	}
	
	public static boolean sonFechasIguales(LocalDate f1, LocalDate f2) {
		return (Funciones.traerFechaCorta(f1).equals(Funciones.traerFechaCorta(f2)));
	}

	
//	private static final List<GregorianCalendar> lstFeriados = cargarLstFeriados();

	public static boolean esHabil(LocalDate f) {
		boolean habil = false;
		/* DayOfWeek().getValue()  Gets the day-of-week int value.
		 * Returns: the day-of-week, from 1 (Monday) to 7 (Sunday) */
		int dia= f.getDayOfWeek().getValue();
		if(dia>=1 && dia<=5)
			habil=true;
		return habil;
	}

	public static int difEntreFechas(LocalDate f1, LocalDate f2) {
		int diaf1= f1.getDayOfMonth();
		int diaf2= f2.getDayOfMonth();
		
		int mesf1=f1.getMonthValue();
		int mesf2=f2.getMonthValue();
		
		int aniof1=f1.getYear();
		int aniof2=f2.getYear();
		
		
		LocalDate auxf1=LocalDate.of(f1.getYear(), f1.getMonthValue(), f1.getDayOfMonth());
		LocalDate auxf2=LocalDate.of(f2.getYear(), f2.getMonthValue(), f2.getDayOfMonth());
		
		int difDias=0;
		if(mesf2==mesf1&&aniof1==aniof2)
			difDias=Math.abs(diaf1-diaf2);
		return difDias;
	}

//	public static GregorianCalendar traerPrimerDiaHabil(GregorianCalendar f) {
//		while (!(esHabil(f))) {
//			f.add(Calendar.DAY_OF_MONTH, 1);
//		}
//
//		return f;
//	}

	public static double redondear(double nro) {
		return (int) (nro * 100 + 0.05) / 100.0;
	}

//	public static List<GregorianCalendar> cargarLstFeriados() {
//		List<GregorianCalendar> lst = new ArrayList();
//		try {
//
//			// Ruta a partir de la carpeta src
//			File dirBase = new File("src/funciones/feriados.xml");
//			// Recupera la ruta a relativa c:\ o /home
//			String ruta = dirBase.getAbsolutePath();
//			// System.out.println(ruta);
//
//			BufferedReader br = new BufferedReader(new FileReader(ruta));
//			String entrada;
//			String cadena = "";
//			while ((entrada = br.readLine()) != null)
//				cadena = cadena + entrada;
//			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//			DocumentBuilder db = dbf.newDocumentBuilder();
//			InputSource archivo = new InputSource();
//			archivo.setCharacterStream(new StringReader(cadena));
//			Document documento = db.parse(archivo);
//			documento.getDocumentElement().normalize();
//			NodeList nodeLista = documento.getElementsByTagName("feriado");// registro
//			for (int s = 0; s < nodeLista.getLength(); s++) {
//				Node nodo = nodeLista.item(s);
//				String anio;
//				String mes;
//				String dia;
//				if (nodo.getNodeType() == Node.ELEMENT_NODE) {
//					Element elemento = (Element) nodo;
//					NodeList primerNombreElementoLista = elemento.getElementsByTagName("anio");
//					Element primerNombreElemento = (Element) primerNombreElementoLista.item(0);
//					NodeList primerNombre = primerNombreElemento.getChildNodes();
//					anio = ((Node) primerNombre.item(0)).getNodeValue().toString();
//					// System.out.println("Anio: " + anio);
//					NodeList segundoNombreElementoLista = elemento.getElementsByTagName("mes");
//					Element segundoNombreElemento = (Element) segundoNombreElementoLista.item(0);
//					NodeList segundoNombre = segundoNombreElemento.getChildNodes();
//					mes = ((Node) segundoNombre.item(0)).getNodeValue().toString();
//					// System.out.println("Mes: " + mes);
//					NodeList tercerNombreElementoLista = elemento.getElementsByTagName("dia");
//					Element tercerNombreElemento = (Element) tercerNombreElementoLista.item(0);
//					NodeList tercerNombre = tercerNombreElemento.getChildNodes();
//					dia = ((Node) tercerNombre.item(0)).getNodeValue().toString();
//					// System.out.println( "lectura"+dia+"/" +mes+"/" +anio);
//
//					lst.add(new GregorianCalendar(Integer.parseInt(anio), Integer.parseInt(mes),
//							Integer.parseInt(dia)));
//				}
//
//			}
//		} catch (Exception e) {// Objeto del tipo Exception
//			System.out.println(e.getMessage()); // Recupero en la vista el error de compilaci��n
//		}
//		// for (GregorianCalendar f:lst)System.out.println("f"+f);
//		return lst;
//	}

}
