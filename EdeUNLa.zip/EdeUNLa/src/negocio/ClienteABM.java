package negocio;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import dao.ClienteDao;
import datos.Cliente;
import datos.DatosPersonales;

public class ClienteABM {
	ClienteDao dao = ClienteDao.getInstanciaClienteDao();

	public Cliente traerCliente(int idCliente) {
		Cliente c = dao.traerCliente(idCliente);
		return c;
	}
	public Cliente traerCliente(long dni) {
		Cliente c = dao.traerCliente(dni);
		return c;
	}
	public int agregar(long dni, String apellido, String nombre, String mail, String direccion, String telefono) throws Exception{
		if(dao.traerCliente(dni)!=null)
			throw new Exception("ERROR: ya existe cliente con dni= "+dni);
		DatosPersonales datosPersonales=new DatosPersonales(dni,apellido,nombre,mail,direccion,telefono);
		DatosPersonalesABM datosABM=new DatosPersonalesABM();
		datosABM.agregar(datosPersonales);
		Cliente c = new Cliente(datosPersonales);
		c.setDatosPersonales(datosPersonales);
		return dao.agregar(c);
	}
	public int agregar(DatosPersonales datosPersonales) throws Exception {
		if(dao.traerCliente(datosPersonales.getDni())!=null)
			throw new Exception("ERROR: ya existe cliente con dni= "+datosPersonales.getDni());
		Cliente c = new Cliente(datosPersonales);
		return dao.agregar(c);
	}

	public void modificar(Cliente c)throws Exception {
		//if(dao.traerCliente(c.getDatosPersonales().getDni())!=null)
		//	throw new Exception("ERROR: dni duplicado, ya existe un cliente con dni= "+c.getDatosPersonales().getDni());
		//Si hago eso no me va a permitir modificar los demas campos si no modifico el id.. Se que podría pisar a otro doc pero esa esta solución produce otro error.
		
		dao.actualizar(c);
	}

	public void eliminar(int idCliente) {
		Cliente c = dao.traerCliente(idCliente);
		dao.eliminar(c);
	}

	public List<Cliente> traerCliente() {
		return dao.traer();
	}
	public void mostrarFilas(HttpServletResponse response) throws IOException{
		ClienteDao clienteDao=ClienteDao.getInstanciaClienteDao(); 
		List<Cliente> lstClientes=clienteDao.traer();
		for(Cliente cliente:lstClientes){
			response.getWriter().append("<tr><td id='c1f"+cliente.getIdCliente()+"'>"+cliente.getDatosPersonales().getDni()
				+"</td> <td id='c2f"+cliente.getIdCliente()+"'>"+ cliente.getDatosPersonales().getNombre()+
				"</td><td id='c3f"+cliente.getIdCliente()+"'>"+cliente.getDatosPersonales().getApellido()
				+"</td><td id='c4f"+cliente.getIdCliente()+"'> "+ cliente.getDatosPersonales().getTelefono()
				+"</td><td id='c5f"+cliente.getIdCliente()+"'><button onclick='modificarCliente("+cliente.getIdCliente()+")'id='boton"+cliente.getIdCliente()+"'>Modificar</button><button onclick='eliminarCliente("+cliente.getIdCliente()+")'>Eliminar</button></tr>");
			
	}
}
}
