package negocio;

import java.util.List;

import dao.DatosPersonalesDao;
import datos.DatosPersonales;
import datos.DatosPersonales;
public class DatosPersonalesABM {
	DatosPersonalesDao dao= DatosPersonalesDao.getInstanciaDatosPersonalesDao();
	
	public DatosPersonales traerDatosPersonales(int idDatosPersonales) {
		return dao.traer(idDatosPersonales);
	}
	public DatosPersonales traerDatosPersonales(long dni) {
		return dao.traer(dni);
	}
	
	public int agregar(long dni, String apellido, String nombre, String mail, String direccion, String telefono) throws Exception{
		if(traerDatosPersonales(dni)!=null)
			throw new Exception("ERROR: ya existe DatosPersonales con dni= "+dni);
		DatosPersonales datosPersonales=new DatosPersonales(dni,apellido,nombre,mail,direccion,telefono);
		return dao.agregar(datosPersonales);
	}
	public int agregar(DatosPersonales datosPersonales) throws Exception {
		if(dao.traer(datosPersonales.getDni())!=null)
			throw new Exception("ERROR: ya existe DatosPersonales con dni= "+datosPersonales.getDni());
		return dao.agregar(datosPersonales);
	}

	public void modificar(DatosPersonales d)throws Exception {
		//if(dao.traerDatosPersonales(c.getDatosPersonales().getDni())!=null)
		//	throw new Exception("ERROR: dni duplicado, ya existe un DatosPersonales con dni= "+c.getDatosPersonales().getDni());
		//Si hago eso no me va a permitir modificar los demas campos si no modifico el id.. Se que podría pisar a otro doc pero esa esta solución produce otro error.
		
		dao.actualizar(d);
	}

	public void eliminar(int idDatosPersonales) {
		DatosPersonales d = dao.traer(idDatosPersonales);
		dao.eliminar(d);
	}
/*
	public List<DatosPersonales> traerDatosPersonales() {
		return dao.traer();
	}
	*/
}
