package negocio;

import java.time.LocalDate;

import datos.Cliente;
import datos.Factura;
import datos.Medidor;

public class FacturaABM {
//	private int idFactura;
//	private int nroSerieMedidor;
//	private String observaciones;
//	private boolean anulada;
//	private LocalDate fecha;
//	private Cliente cliente;
	
	
	public double calcularPrecio(Factura f) {
		//segun consumo o potencia contratada
		
		
	}
	
	
	public Factura generarFactura(Medidor medidor,int mes,int anio, String observaciones){
		LocalDate fecha=LocalDate.of(anio, mes, 10);
		Factura f=new Factura(medidor.getNroSerie(),observaciones,false,fecha,medidor.getCliente());
		return f;
	}
	
	
}
