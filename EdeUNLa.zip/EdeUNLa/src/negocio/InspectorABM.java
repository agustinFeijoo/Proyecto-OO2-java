package negocio;

import dao.InspectorDao;
import datos.Inspector;

public class InspectorABM {
	InspectorDao dao= InspectorDao.getInstanciaInspectorDao();
	
	public Inspector traerInspector(int idInspector) {
		return dao.traer(idInspector);
	}
	
	public Inspector traerInspector(long dni) {
		return dao.traer(dni);
	}
	
	
}
