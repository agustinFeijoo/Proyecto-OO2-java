package negocio;

import java.time.LocalDate;
import java.util.List;

import dao.LecturaDao;
import datos.Inspector;
import datos.Lectura;
import datos.LecturaAD;
import datos.LecturaBD;
import datos.Medidor;

public class LecturaABM {
	LecturaDao dao= LecturaDao.getInstance();
	
	public Lectura traer(int idLectura) {
		return dao.traer(idLectura);
	}
	
	public List<Lectura> traer(Medidor medidor) {
		return dao.traer(medidor);
	}
	
	public Lectura traer(Medidor medidor,int mes,int anio) {
		return dao.traer(medidor,mes,anio);
	}
	
	public int agregarLecturaAltaDemanda(Inspector inspector, Medidor medidor, LocalDate fecha,float consumoPico,float consumoValle, float consumoResto) throws Exception{
		LecturaAD l=new LecturaAD(inspector, medidor, fecha, consumoPico, consumoValle, consumoResto);
		return dao.agregarLecturaAltaDemanda(l);
	}
	
	public int agregarLecturaBajaDemanda(Inspector inspector, Medidor medidor, LocalDate fecha, float consumo) throws Exception{
		LecturaBD l= new LecturaBD(inspector, medidor, fecha, consumo);
		return dao.agregarLecturaBajaDemanda(l);
	}
	
	
}
