package negocio;

import java.time.LocalDate;

import dao.LecturaAltaDao;
import datos.Inspector;
import datos.LecturaAD;
import datos.Medidor;
import datos.Zona;

public class LecturaAltaABM {
	LecturaAltaDao dao = LecturaAltaDao.getInstance();
	
	public LecturaAD traer(int idLecturaAD) {
		return dao.traer(idLecturaAD);
	}
	
	public int agregar(Inspector inspector, Medidor medidor, LocalDate fecha,float consumoPico,float consumoValle, float consumoResto)throws Exception{
		if(traer(descripcion)!=null)
			throw new Exception("ERROR: ya existe la zona");
		Zona zona = new Zona(descripcion);
		return dao.agregar(zona);
	}
	
	public void modificar(Zona zona) throws Exception{
		if(traer(zona.getDescripcion())!=null)
			throw new Exception("ERROR: ya existe la zona");
		dao.actualizar(zona);
	}
	
	public void eliminar(Zona zona) throws Exception{
		dao.eliminar(zona);
	}}
