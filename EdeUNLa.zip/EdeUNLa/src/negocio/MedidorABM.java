package negocio;

import java.util.List;
import java.util.Set;

import dao.MedidorDao;
import datos.Cliente;
import datos.Inspector;
import datos.Medidor;
import datos.Tarifa;
import datos.Zona;

public class MedidorABM {
	MedidorDao dao = MedidorDao.getInstance();
	
	public Medidor traer(int idMedidor) {
		return dao.traer(idMedidor);
	}
	
	public Medidor traer(long nroSerie) {
		return dao.traer(nroSerie);
	}
	
	public List<Medidor> traer(){
		return dao.traer();
	}
	
	public int agregar(long nroSerie, Cliente cliente, String descripcion, Zona zona, String tipoDemanda, Tarifa tarifa)throws Exception{
		if(traer(nroSerie)!=null)
			throw new Exception("ERROR: ya existe medidor con nroSerie: "+nroSerie);
		Medidor medidor = new Medidor(nroSerie,cliente,descripcion,zona,tipoDemanda,tarifa);
		return dao.agregar(medidor);
	}
	
	public void modificar(Medidor medidor) throws Exception{
		if(traer(medidor.getNroSerie())!=null)
			throw new Exception("ERROR: ya existe medidor con nroSerie: "+medidor.getNroSerie());
		dao.actualizar(medidor);
	}
	
	public void eliminar(Medidor medidor) throws Exception{
		dao.eliminar(medidor);
	}
}
