package negocio;

import java.util.List;

import dao.TarifaDao;
import datos.Tarifa;
import datos.TarifaAD;
import datos.TarifaBD;

public class TarifaABM {
	TarifaDao dao = TarifaDao.getInstance();
	
	public Tarifa traer(int idTarifa) {
		return dao.traer(idTarifa);
	}
	
	public Tarifa traer(String categoria) {
		return dao.traer(categoria);
	}
	
	public List<Tarifa>traer(){
		return dao.traer();
	}
	
	public TarifaAD traerTarifaAlta(int id) {
		Tarifa aux=traer(id);
		TarifaAD t=null;
		if(aux instanceof TarifaAD) {
			t=(TarifaAD)aux;
		}
		return t;
	}

	public TarifaBD traerTarifaBaja(int id) {
		Tarifa aux=traer(id);
		TarifaBD t=null;
		if(aux instanceof TarifaBD) {
			t=(TarifaBD)aux;
		}
		return t;
	}
	
//	public void agregarTarifaAlta(String categoria, float cargoFijo, float cargoVarPico,
//			float cargoVarResto, float cargoVarValle) throws Exception{
//		if(traer(categoria)!=null)
//			throw new Exception("Ya existe tarifa con categoria:"+ categoria); 
//		TarifaAD tarifa= new TarifaAD(categoria,cargoFijo,cargoVarPico,cargoVarResto,cargoVarValle);
//		return dao.agregar(tarifa);	
//	}
}

