package negocio;

import dao.TarifaADDao;
import datos.TarifaAD;

public class TarifaAltaABM {
	TarifaADDao dao = TarifaADDao.getInstance();
	
	public TarifaAD traer(int idTarifaAD) {
		return dao.traer(idTarifaAD);
	}
}
