package negocio;

import dao.TarifaBDDao;
import datos.TarifaBD;

public class TarifaBajaABM {
	TarifaBDDao dao = TarifaBDDao.getInstance();
	
	public TarifaBD traer(int idTarifaBD) {
		return dao.traer(idTarifaBD);
	}

}
