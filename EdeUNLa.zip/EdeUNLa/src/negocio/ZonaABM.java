package negocio;

import java.util.List;
import java.util.Set;

import dao.ZonaDao;
import datos.Inspector;
import datos.Zona;

public class ZonaABM {
	ZonaDao dao= ZonaDao.getInstance();
	
	public Zona traer(int idZona) {
		return dao.traer(idZona);
	}
	
	public Zona traer(String descripcion) {
		return dao.traer(descripcion);
	}
	
	public List<Zona>traer(){
		return dao.traer();
	}
	
//	public int agregar(Set<Inspector> lstInspector,String descripcion)throws Exception{
//		if(traer(descripcion)!=null)
//			throw new Exception("ERROR: ya existe la zona");
//		Zona zona = new Zona(descripcion,lstInspector);
//		return dao.agregar(zona);
//	}
	
	public int agregar(String descripcion)throws Exception{
		if(traer(descripcion)!=null)
			throw new Exception("ERROR: ya existe la zona");
		Zona zona = new Zona(descripcion);
		return dao.agregar(zona);
	}
	
	public void modificar(Zona zona) throws Exception{
		if(traer(zona.getDescripcion())!=null)
			throw new Exception("ERROR: ya existe la zona");
		dao.actualizar(zona);
	}
	
	public void eliminar(Zona zona) throws Exception{
		dao.eliminar(zona);
	}
}
