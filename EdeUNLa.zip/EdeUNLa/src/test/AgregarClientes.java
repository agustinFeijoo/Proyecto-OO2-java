package test;

import negocio.ClienteABM;

public class AgregarClientes {
	public static void main(String[] args) {
		try {
			
			//en clienteABM comentada la excepcion
			ClienteABM abm= new ClienteABM();
			abm.agregar(26647513, "Lopez", "Jessica", "jesica78@gmail.com", "Chacabuco 235", "45268745");
			abm.agregar(28459731, "Mu�oz", "Lourdes", "lourdes123@hotmail.com", "Charcas 654", "41258745");
			abm.agregar(13266335, "Fernandez", "Marcelo", "marceloFernandez@gmail.com", "Pintos 1689", "35681297");
			abm.agregar(32587461, "Martinez", "Carlos", "carlos588@yahoo.com.ar", "Matheu 544", "42697156");
			
						
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
