package test;

import java.time.LocalDate;

import datos.Inspector;
import datos.Medidor;
import negocio.InspectorABM;
import negocio.LecturaABM;
import negocio.MedidorABM;

public class AgregarLecturas {
	public static void main(String[] args) {
		try {
			LecturaABM abmLectura= new LecturaABM();
			InspectorABM abmInspector= new InspectorABM();
			Inspector inspector= abmInspector.traerInspector(1);
			
			MedidorABM abmMedidor = new MedidorABM();
			Medidor medidor= abmMedidor.traer(123456l);
			
			LocalDate fecha= LocalDate.of(2019, 1, 10);
			
			
			abmLectura.agregarLecturaBajaDemanda(inspector, medidor, fecha,800);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
