package test;

import java.util.List;

import datos.Cliente;
import datos.Tarifa;
import datos.Zona;
import negocio.ClienteABM;
import negocio.MedidorABM;
import negocio.TarifaABM;
import negocio.ZonaABM;

public class AgregarMedidores {
	public static void main(String[] args) {
		try {
			MedidorABM abm= new MedidorABM();
			ClienteABM abmCliente= new ClienteABM();
			ZonaABM abmZona= new ZonaABM();
			TarifaABM abmTarifa = new TarifaABM();
			
			Cliente c1=abmCliente.traerCliente(1);
			Cliente c2=abmCliente.traerCliente(2);
			
			Zona z1=abmZona.traer("Banfield");
			Zona z2=abmZona.traer(2);
			Zona z3=abmZona.traer(3);

			//no anda
//			List<Zona> zonas = abmZona.traer();
//			System.out.println(zonas);
			
			Tarifa t1=abmTarifa.traer("T1 - R1 0-150");
			
			//abm.agregar(123456l, c1, "Chacabuco 235", z1, "Baja demanda: T1 - R1 0-150", t1);
		
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
