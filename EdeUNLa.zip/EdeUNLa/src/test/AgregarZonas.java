package test;

import negocio.ZonaABM;

public class AgregarZonas {
	public static void main(String[] args) {
		try {
			ZonaABM abm= new ZonaABM();
			abm.agregar("Banfield");
			abm.agregar("Lanus");
			abm.agregar("Temperley");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
