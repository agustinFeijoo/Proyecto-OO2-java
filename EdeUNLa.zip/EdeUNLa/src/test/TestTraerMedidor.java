package test;

import java.util.List;

import datos.Lectura;
import datos.Medidor;
import negocio.LecturaABM;
import negocio.MedidorABM;

public class TestTraerMedidor {
	public static void main(String[] args) {
		try {
			MedidorABM abmMedidor = new MedidorABM();
			Medidor medidor= abmMedidor.traer(1);
			System.out.println(medidor);
			
			LecturaABM abm= new LecturaABM();
			
			//List<Lectura> lista= abmMedidor.traer(medidor.getIdMedidor()).getLecturas; la lista de lecturas no esta mapeada,no se puede realizar
		//	System.out.println(lista);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
